% M = quarter2_2009(x);

function M = quarter2_2009(x)
    M = x(1) + x(2)*2009.25;
end