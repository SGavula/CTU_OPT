function d = erraff(A)
    b0 = mean(A,2);
    A = A - b0;
    [m, ~] = size(A);
    [~, S, ~] = svd(A);
    d = zeros(m, 1);
    dia_eigenvalues = diag(S).^2;
    total = sum(dia_eigenvalues);
    for k = 1:m
         d(k) = total - sum(dia_eigenvalues(1:k)); 
    end
end

